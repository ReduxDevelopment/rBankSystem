This program is fully customizable and free to use.

Also you can you names in program, not only numbers.

Example:


1 | Deposit
2 | Withdraw

output: "deposit"
output2: "2"

Try it by yourself! I hope you'll enjoy this program






																	@vojtechbracho
																	@ReduxDevelopment.eu 2023