package reduxdevelopment.BankSystem;

/**
 * With hearth created by vojtechbracho for ReduxDevelopment.eu!
 *
 * @author vojtechbracho
 * @date 19.05.2023
 * @development_time 1h 30m
 * @version 1.1.1
 */

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.getMenu();
    }
}
