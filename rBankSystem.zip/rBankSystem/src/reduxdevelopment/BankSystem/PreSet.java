package reduxdevelopment.BankSystem;

/**
 * PRESET FOR WHOLE PROJECT
 * @author vojtechbracho
 * @date 19.05.2023
 * @version 1.1.1
 */
public class PreSet {
    public static long money = 1000; // money in your pocket
    public static long bankmoney = 500; // money in your bank

}
